#include "bsp_audio.h"
#include "stm32f4xx_hal.h"
#include "cs43l22.h"

#define I2C_TIMEOUT  100
#define AUDIO_I2C_ADDRESS                     0x94
#define AUDIO_OK         0x00
#define AUDIO_ERROR      0x01
#define AUDIO_TIMEOUT    0x02
#define AUDIODATA_SIZE              2
#define DMA_MAX_SZE                         0xFFFF
#define DMA_MAX(x)           (((x) <= DMA_MAX_SZE)? (x):DMA_MAX_SZE)

AUDIO_DrvTypeDef   *audio_drv;
extern I2C_HandleTypeDef hi2c1;
extern I2S_HandleTypeDef hi2s3;

//---------------------for c43l22 port--------------------------//
static void I2Cx_Error(uint8_t Addr)
{
  /* De-initialize the IOE comunication BUS */
  HAL_I2C_DeInit(&hi2c1);

  /* Re-Initiaize the IOE comunication BUS */
  //I2Cx_Init();
  //MX_I2C1_Init();
}
static void CODEC_Reset(void)
{
#if 1
	HAL_GPIO_WritePin(AUDIO_RESET_GPIO_Port, AUDIO_RESET_Pin, GPIO_PIN_RESET);
	HAL_Delay(5);
	HAL_GPIO_WritePin(AUDIO_RESET_GPIO_Port, AUDIO_RESET_Pin, GPIO_PIN_SET);
	HAL_Delay(5);
#endif
}
void AUDIO_IO_Init(void)
{
  //I2Cx_Init();
}
void AUDIO_IO_DeInit(void)
{

}
/**
  * @brief  Writes a single data.
  * @param  Addr: I2C address
  * @param  Reg: Reg address
  * @param  Value: Data to be written
  */
static void I2Cx_Write(uint8_t Addr, uint8_t Reg, uint8_t Value)
{
  HAL_StatusTypeDef status = HAL_OK;

  status = HAL_I2C_Mem_Write(&hi2c1, Addr, (uint16_t)Reg, I2C_MEMADD_SIZE_8BIT, &Value, 1, I2C_TIMEOUT);

  /* Check the communication status */
  if(status != HAL_OK)
  {
    /* I2C error occured */
    I2Cx_Error(Addr);
  }
}
void AUDIO_IO_Write(uint8_t Addr, uint8_t Reg, uint8_t Value)
{
  I2Cx_Write(Addr, Reg, Value);
}

/**
  * @brief  Reads a single data.
  * @param  Addr: I2C address
  * @param  Reg: Reg address
  * @retval Data to be read
  */
static uint8_t I2Cx_Read(uint8_t Addr, uint8_t Reg)
{
  HAL_StatusTypeDef status = HAL_OK;
  uint8_t Value = 0;

  status = HAL_I2C_Mem_Read(&hi2c1, Addr, Reg, I2C_MEMADD_SIZE_8BIT, &Value, 1, I2C_TIMEOUT);

  /* Check the communication status */
  if(status != HAL_OK)
  {
    /* Execute user timeout callback */
    I2Cx_Error(Addr);
  }

  return Value;
}
uint8_t AUDIO_IO_Read(uint8_t Addr, uint8_t Reg)
{
  return I2Cx_Read(Addr, Reg);
}
//----------------for usbd_audio_if port--------------------//
static void I2Sx_Init(uint32_t AudioFreq)
{
  /* Initialize the haudio_i2s Instance parameter */
  hi2s3.Instance = SPI3;

 /* Disable I2S block */
  __HAL_I2S_DISABLE(&hi2s3);

  hi2s3.Init.Mode = I2S_MODE_MASTER_TX;
  hi2s3.Init.Standard = I2S_STANDARD;
  hi2s3.Init.DataFormat = I2S_DATAFORMAT_16B;
  hi2s3.Init.AudioFreq = AudioFreq;
  hi2s3.Init.CPOL = I2S_CPOL_LOW;
  hi2s3.Init.MCLKOutput = I2S_MCLKOUTPUT_ENABLE;

  if(HAL_I2S_GetState(&hi2s3) == HAL_I2S_STATE_RESET)
  {
    HAL_I2S_MspInit(&hi2s3);
  }
  /* Init the I2S */
  HAL_I2S_Init(&hi2s3);
}
const uint32_t I2SFreq[8] = {8000, 11025, 16000, 22050, 32000, 44100, 48000, 96000};
const uint32_t I2SPLLN[8] = {256, 429, 213, 429, 426, 271, 258, 344};
const uint32_t I2SPLLR[8] = {5, 4, 4, 4, 4, 6, 3, 1};
uint8_t BSP_AUDIO_OUT_Init(uint16_t OutputDevice, uint8_t Volume, uint32_t AudioFreq)
{
	uint32_t deviceid = 0x00;
	uint8_t ret = AUDIO_ERROR;
	uint8_t index = 0, freqindex = 0xFF;
	RCC_PeriphCLKInitTypeDef RCC_ExCLKInitStruct;

	//get the according P,N value and set into config,this is for audio clock provide
	for(index = 0; index < 8; index++)
	{
		if(I2SFreq[index] == AudioFreq)
		{
			freqindex = index;
		}
	}
	HAL_RCCEx_GetPeriphCLKConfig(&RCC_ExCLKInitStruct);
	if(freqindex != 0xFF)
	{
		RCC_ExCLKInitStruct.PeriphClockSelection = RCC_PERIPHCLK_I2S;
    	RCC_ExCLKInitStruct.PLLI2S.PLLI2SN = I2SPLLN[freqindex];
    	RCC_ExCLKInitStruct.PLLI2S.PLLI2SR = I2SPLLR[freqindex];
    	HAL_RCCEx_PeriphCLKConfig(&RCC_ExCLKInitStruct);
	}
	else
	{
		RCC_ExCLKInitStruct.PeriphClockSelection = RCC_PERIPHCLK_I2S;
    	RCC_ExCLKInitStruct.PLLI2S.PLLI2SN = 258;
    	RCC_ExCLKInitStruct.PLLI2S.PLLI2SR = 3;
    	HAL_RCCEx_PeriphCLKConfig(&RCC_ExCLKInitStruct);
	}

	//reset the Codec register
	CODEC_Reset();
	deviceid = cs43l22_drv.ReadID(AUDIO_I2C_ADDRESS);
	if((deviceid & CS43L22_ID_MASK) == CS43L22_ID)
	  {
		/* Initialize the audio driver structure */
		audio_drv = &cs43l22_drv;
		ret = AUDIO_OK;
	  }
	  else
	  {
		ret = AUDIO_ERROR;
	  }

	 if(ret == AUDIO_OK)
	  {
		audio_drv->Init(AUDIO_I2C_ADDRESS, OutputDevice, Volume, AudioFreq);
		/* I2S data transfer preparation:
		Prepare the Media to be used for the audio transfer from memory to I2S peripheral */
		/* Configure the I2S peripheral */
		I2Sx_Init(AudioFreq);
	  }
	return AUDIO_OK;
}
uint8_t BSP_AUDIO_OUT_Stop(uint32_t Option)
{
  /* Call the Media layer stop function */
  HAL_I2S_DMAStop(&hi2s3);

  /* Call Audio Codec Stop function */
  if(audio_drv->Stop(AUDIO_I2C_ADDRESS, Option) != 0)
  {
    return AUDIO_ERROR;
  }
  else
  {
    if(Option == CODEC_PDWN_HW)
    {
      /* Wait at least 1ms */
      HAL_Delay(1);

      /* Reset the pin */
      //BSP_IO_WritePin(AUDIO_RESET_PIN, RESET);
	  HAL_GPIO_WritePin(AUDIO_RESET_GPIO_Port, AUDIO_RESET_Pin, GPIO_PIN_RESET);
    }

    /* Return AUDIO_OK when all operations are correctly done */
    return AUDIO_OK;
  }
}

uint8_t BSP_AUDIO_OUT_Play(uint16_t* pBuffer, uint32_t Size)
{
  /* Call the audio Codec Play function */
  if(audio_drv->Play(AUDIO_I2C_ADDRESS, pBuffer, Size) != 0)
  {
    return AUDIO_ERROR;
  }
  else
  {
    /* Update the Media layer and enable it for play */
    HAL_I2S_Transmit_DMA(&hi2s3, pBuffer, DMA_MAX(Size/AUDIODATA_SIZE));
    return AUDIO_OK;
  }
}
void BSP_AUDIO_OUT_ChangeBuffer(uint16_t *pData, uint16_t Size)
{
  HAL_I2S_Transmit_DMA(&hi2s3, pData, Size);
}
uint8_t BSP_AUDIO_OUT_SetVolume(uint8_t Volume)
{
  /* Call the codec volume control function with converted volume value */
  if(audio_drv->SetVolume(AUDIO_I2C_ADDRESS, Volume) != 0)
  {
    return AUDIO_ERROR;
  }
  else
  {
    /* Return AUDIO_OK when all operations are correctly done */
    return AUDIO_OK;
  }
}
uint8_t BSP_AUDIO_OUT_SetMute(uint32_t Cmd)
{
  /* Call the Codec Mute function */
  if(audio_drv->SetMute(AUDIO_I2C_ADDRESS, Cmd) != 0)
  {
    return AUDIO_ERROR;
  }
  else
  {
    /* Return AUDIO_OK when all operations are correctly done */
    return AUDIO_OK;
  }
}

//-------------------for I2s interrupt--------------------------//
void HAL_I2S_TxCpltCallback(I2S_HandleTypeDef *hi2s)
{
  /* Manage the remaining file size and new address offset: This function
     should be coded by user (its prototype is already declared in stm324xg_eval_audio.h) */
  //BSP_AUDIO_OUT_TransferComplete_CallBack();
		TransferComplete_CallBack_FS();
}

/**
  * @brief Tx Transfer Half completed callbacks
  * @param hi2s: I2S handle
  */
void HAL_I2S_TxHalfCpltCallback(I2S_HandleTypeDef *hi2s)
{
  /* Manage the remaining file size and new address offset: This function
     should be coded by user (its prototype is already declared in stm324xg_eval_audio.h) */
  //BSP_AUDIO_OUT_HalfTransfer_CallBack();
		HalfTransfer_CallBack_FS();
}

/**
  * @brief  I2S error callbacks.
  * @param  hi2s: I2S handle
  */
void HAL_I2S_ErrorCallback(I2S_HandleTypeDef *hi2s)
{
  //BSP_AUDIO_OUT_Error_CallBack();
}
